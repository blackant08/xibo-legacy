<div class="list-group">
	<a class="list-group-item" href="index.php?toc=library&p=content/overview">Overview</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/adding">Uploading Content</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/editing">Editing Content</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/deleting">Deleting Content</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/content_video">Video</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/content_flash">Flash</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/content_image">Image</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/content_powerpoint">PowerPoint</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/content_dataset">DataSets</a>
	<a class="list-group-item" href="index.php?toc=library&p=content/content_genericfile">Generic File</a>
	<a class="list-group-item" href="index.php?toc=library&p=admin/modules">Media Modules</a>
</div>