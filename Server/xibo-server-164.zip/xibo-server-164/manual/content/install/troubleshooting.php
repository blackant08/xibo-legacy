
	<h1>Troubleshooting</h1>

	<p>Please head over to our Support page if you have problems installing <?php echo PRODUCT_NAME; ?>.</p>
	<p><a href="<?php echo PRODUCT_SUPPORT_URL; ?>" target="_blank"><?php echo PRODUCT_SUPPORT_URL; ?></a>
	<p>Be sure to checkout the FAQs too.</p>
	<p><a href="<?php echo PRODUCT_FAQ_URL; ?>" target="_blank"><?php echo PRODUCT_FAQ_URL; ?></a></p>