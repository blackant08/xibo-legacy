
<h3> <span class="mw-headline" id="Other"> Other </span></h3>
<ul><li> Version
</li><li> ServerStatus
</li></ul>


<h3> <span class="mw-headline" id="Version"> Version </span></h3>
<p>Response
</p>
<pre>&lt;?xml version="1.0"?&gt;
&lt;rsp status="ok"&gt;
    &lt;version app_ver="1.1.1" XlfVersion="1" XmdsVersion="2" DBVersion="22"/&gt;
&lt;/rsp&gt;
</pre>