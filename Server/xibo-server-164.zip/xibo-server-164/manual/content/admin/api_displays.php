<h3> <span class="mw-headline" id="Displays"> Displays </span></h3>
<ul><li> DisplayList
</li><li> DisplayEdit
</li><li> DisplayRetire
</li><li> DisplayDelete
</li><li> DisplayUserGroupSecurity
</li><li> DisplayUserGroupEdit
</li></ul>