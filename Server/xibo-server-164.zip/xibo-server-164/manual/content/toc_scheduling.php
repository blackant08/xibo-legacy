<div class="list-group">
	<a class="list-group-item" href="index.php?toc=scheduling&p=schedule/overview">Overview</a>
	<a class="list-group-item" href="index.php?toc=scheduling&p=schedule/schedule_event">Schedule Events</a>
	<a class="list-group-item" href="index.php?toc=scheduling&p=schedule/schedule_now">Schedule Now</a>
</div>