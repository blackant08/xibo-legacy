<div class="list-group">
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/overview">Overview</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/layoutdesigner">Layout Designer</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/addregion">Regions</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/assigncontent">Region Timelines</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_text">- Text</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_ticker">- Ticker</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_counter">- Counter</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_webpage">- Web Page</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_embedded">- Embedded</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_datasetview">- DataSet View</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/content_shellcommand">- Shell Command</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/region_preview_timeline">Previewing</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/transitions">Transitions</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=layout/campaign_layout">Campaigns</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=templates/overview">Templates</a>
	<a class="list-group-item" href="index.php?toc=layouts&p=templates/template_resolution">Resolutions</a>
</div>